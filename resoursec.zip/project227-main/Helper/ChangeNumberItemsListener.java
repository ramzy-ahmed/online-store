package com.uilover.project2272.Helper;

public interface ChangeNumberItemsListener {
    void changed();
}
